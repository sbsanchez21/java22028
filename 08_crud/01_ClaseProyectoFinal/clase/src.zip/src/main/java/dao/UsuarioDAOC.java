package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dataBase.ConexionDB;

public class UsuarioDAOC {
	
	public Boolean validarUsuYPass(String usu, String pass) throws SQLException {
		ConexionDB conexionDB = new ConexionDB();
		Connection conn= conexionDB.establecerConexion();
		Statement st= conn.createStatement();
		
		ResultSet rs = st.executeQuery("SELECT * FROM usuarios WHERE usuario='"+ usu +"' and clave='"+ pass + "'");
		
		if (rs.next()) {
			return true;
		} else {
			return false;
		}

		
	}
	

}

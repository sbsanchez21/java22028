package argPrograma;

public class Domicilio {
	private Integer id;
	private String calle;
	private String altura;
	private String codPostal;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCalle() {
		return calle;
	}
	public void setCalle(String calle) {
		this.calle = calle;
	}
	public String getAltura() {
		return altura;
	}
	public void setAltura(String altura) {
		this.altura = altura;
	}
	public String getCodPostal() {
		return codPostal;
	}
	public void setCodPostal(String codPostal) {
		this.codPostal = codPostal;
	}
	
	public void modificarCalleYAltura(String calle, String altura) {
		// TODO Auto-generated method stub

	}

}
